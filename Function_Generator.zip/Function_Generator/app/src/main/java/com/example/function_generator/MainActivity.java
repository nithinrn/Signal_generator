/***************************************************************************************
*Author: Nithin RN
*Date:02-04-2019
*Description: This is android application called Function Generator which generates different
*signals like Sinewave, Squarewave and Sawtooth in a smartphone. The output is obtained at
*the audio port of the Smartphone. Due to hardware limitation of Android phones Dc signal
*can't be generated but this application contains code for DC generation as well.
****************************************************************************************/

package com.example.function_generator;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    double freq;
    boolean on ;
    boolean firstHit=false ;
    Thread t1;
    generateSine sinestart;
    generateSquare squarestart;
    generateSawtooth swatoothstart;
    generateDC DCstart;
    String buttonClicked;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText editText = (EditText) findViewById(R.id.FreqeditText);

        // four toggle buttons Sine, Square, DC and Sawtooth
        ToggleButton sintoggle = (ToggleButton) findViewById(R.id.sinetoggleButton);
        ToggleButton squaretoggle = (ToggleButton) findViewById(R.id.squaretoggleButton2);
        ToggleButton DCtoggle = (ToggleButton) findViewById(R.id.DCtoggleButton4);
        ToggleButton Sawtoothtoggle = (ToggleButton) findViewById(R.id.sawtoggleButton3);

        sintoggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                freq = Double.parseDouble(editText.getText().toString());
                sinestart = new generateSine();
                if (isChecked) {
                    sinestart.ison = true;
                    sinestart.frequency = freq;
                    sinestart.start();
                } else {
                    sinestart.stop();
                }
            }
        });

        squaretoggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                freq = Double.parseDouble(editText.getText().toString());
                squarestart=new generateSquare();
                if (isChecked) {
                    // on=true;
                    squarestart.ison=true;
                    squarestart.frequency=freq;
                    squarestart.start();
                } else {
                    squarestart.stop();
                }
                //GenerateSquare(freq,10);
            }
        });
        Sawtoothtoggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                freq = Double.parseDouble(editText.getText().toString());
                 swatoothstart= new generateSawtooth();
                if (isChecked) {
                    swatoothstart.ison=true;
                    swatoothstart.frequency=freq;
                    swatoothstart.start();
                } else {
                    swatoothstart.stop();
                }
                //GenerateSquare(freq,10);
            }
        });
        DCtoggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                freq = Double.parseDouble(editText.getText().toString());
                DCstart= new generateDC();
                if (isChecked) {
                    DCstart.ison=true;
                    DCstart.frequency=freq;
                    DCstart.start();
                } else {
                    DCstart.stop();
                }
            }
        });
    }
}



class generateSine implements Runnable {
    public static boolean ison;
    public static boolean exit=false;
    public static double frequency;
    static AudioTrack mAudioTrack ;
    private  Thread thread;
    int duration=10;
    private Thread t;

    public void run() {

        while (!exit && ison == true) {
        short buffer[];
        int mBufferSize = AudioTrack.getMinBufferSize(44100,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_8BIT);

        mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, 44100,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                mBufferSize, AudioTrack.MODE_STREAM);
        final int sampleRate = 22050;
        final int numSamples = duration * sampleRate;
        // Sine wave
        double[] mSound = new double[numSamples];
        short[] mBuffer = new short[numSamples];
            for (int i = 0; i < mSound.length; i++) {
                mSound[i] = Math.sin((2.0 * Math.PI * i / (44100 / frequency)));
                mBuffer[i] = (short) (mSound[i] * Short.MAX_VALUE);
            }

            mAudioTrack.setStereoVolume(AudioTrack.getMaxVolume(), AudioTrack.getMaxVolume());
            mAudioTrack.play();

            mAudioTrack.write(mBuffer, 0, mSound.length);
        }
    }


    protected void start() {
        thread = new Thread(this, "Audio");
        thread.start();
        thread.getStackTrace();
    }
    protected void stop()  {

        ison=false;
        mAudioTrack.flush();
        mAudioTrack.stop();
        mAudioTrack.release();
    }
}

class generateSquare implements Runnable {
    public static boolean ison;
    public static boolean exit=false;
    public static double frequency;
    static AudioTrack mAudioTrack ;
    private  Thread thread;
    int duration=10;
    private Thread t;

    public void run() {



            short buffer[];

            int mBufferSize = AudioTrack.getMinBufferSize(44100,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_8BIT);

            mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, 44100,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    mBufferSize, AudioTrack.MODE_STREAM);
            final int sampleRate = 22050;
            final int numSamples = duration * sampleRate;
            // Sine wave
            double[] mSound = new double[numSamples];
            short[] mBuffer = new short[numSamples];
        mAudioTrack.setStereoVolume(AudioTrack.getMaxVolume(), AudioTrack.getMaxVolume());
        mAudioTrack.play();
        while (!exit && ison == true) {
            for (int i = 0; i < mSound.length; i++) {
                mSound[i] = Math.sin((2.0 * Math.PI * i / (44100 / frequency)));
                if (mSound[i]>=0){
                    mSound[i]=1;
                }
                else{
                    mSound[i]=0;}
                mBuffer[i] = (short) (mSound[i] * Short.MAX_VALUE);
            }
            mAudioTrack.write(mBuffer, 0, mSound.length);
        }
    }


    protected void start() {
        thread = new Thread(this, "Audio");
        thread.start();
        thread.getStackTrace();
    }
    protected void stop()  {

        ison=false;
        mAudioTrack.flush();
        mAudioTrack.stop();
        mAudioTrack.release();
    }
}

class generateSawtooth implements Runnable {
    public static boolean ison;
    public static boolean exit=false;
    public static double frequency;
    protected double level;
    static AudioTrack mAudioTrack ;
    private  Thread thread;
    int duration=10;
    private Thread t;

    public void run() {

        while (!exit && ison == true) {

            short buffer[];

            int mBufferSize = AudioTrack.getMinBufferSize(44100,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_8BIT);

            mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, 44100,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    mBufferSize, AudioTrack.MODE_STREAM);
            final int sampleRate = 22050;
            final int numSamples = duration * sampleRate;
            // Sine wave
            double[] mSound = new double[numSamples];
            short[] mBuffer = new short[numSamples];


            for (int i = 0; i < mSound.length; i++) {
                mSound[i] = 2*(i%(sampleRate/frequency))/(sampleRate/frequency)-1;
                mBuffer[i] = (short) (mSound[i] * Short.MAX_VALUE);
            }

            mAudioTrack.setStereoVolume(AudioTrack.getMaxVolume(), AudioTrack.getMaxVolume());
            mAudioTrack.play();

            mAudioTrack.write(mBuffer, 0, mSound.length);
        }
    }


    protected void start() {
        thread = new Thread(this, "Audio");
        thread.start();
        thread.getStackTrace();
    }
    protected void stop()  {

        ison=false;
        mAudioTrack.flush();
        mAudioTrack.stop();
        mAudioTrack.release();
    }
}

class generateDC implements Runnable {
    public static boolean ison;
    public static boolean exit=false;
    public static double frequency;
    protected double level;
    static AudioTrack mAudioTrack ;
    private  Thread thread;
    int duration=50;
    private Thread t;

    public void run() {

        while (!exit && ison == true) {

            short buffer[];

            int mBufferSize = AudioTrack.getMinBufferSize(44100,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_8BIT);

            mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, 44100,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    mBufferSize, AudioTrack.MODE_STREAM);
            final int sampleRate = 22050;
            final int numSamples = duration * sampleRate;
            // Sine wave
            double[] mSound = new double[numSamples];
            short[] mBuffer = new short[numSamples];


            for (int i = 0; i < mSound.length; i++) {
                mSound[i] = 1.0;
                mBuffer[i] = (short) (mSound[i] * Short.MAX_VALUE);
            }

            mAudioTrack.setStereoVolume(AudioTrack.getMaxVolume(), AudioTrack.getMaxVolume());
            mAudioTrack.play();

            mAudioTrack.write(mBuffer, 0, mSound.length);
        }
    }


    protected void start() {
        thread = new Thread(this, "Audio");
        thread.start();
        thread.getStackTrace();
    }
    protected void stop()  {

        ison=false;
        mAudioTrack.flush();
        mAudioTrack.stop();
        mAudioTrack.release();
    }
}

